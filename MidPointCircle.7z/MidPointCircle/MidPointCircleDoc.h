// MidPointCircleDoc.h : interface of the CMidPointCircleDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MIDPOINTCIRCLEDOC_H__47F2BE6F_BA8B_4BED_AD16_A4D3BA120897__INCLUDED_)
#define AFX_MIDPOINTCIRCLEDOC_H__47F2BE6F_BA8B_4BED_AD16_A4D3BA120897__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMidPointCircleDoc : public CDocument
{
protected: // create from serialization only
	CMidPointCircleDoc();
	DECLARE_DYNCREATE(CMidPointCircleDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMidPointCircleDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMidPointCircleDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMidPointCircleDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MIDPOINTCIRCLEDOC_H__47F2BE6F_BA8B_4BED_AD16_A4D3BA120897__INCLUDED_)
