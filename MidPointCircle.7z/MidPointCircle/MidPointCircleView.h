// MidPointCircleView.h : interface of the CMidPointCircleView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MIDPOINTCIRCLEVIEW_H__4D7E4A7A_1390_42C6_B502_BEA1F06EFD3A__INCLUDED_)
#define AFX_MIDPOINTCIRCLEVIEW_H__4D7E4A7A_1390_42C6_B502_BEA1F06EFD3A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMidPointCircleView : public CView
{
protected: // create from serialization only
	CMidPointCircleView();
	DECLARE_DYNCREATE(CMidPointCircleView)

// Attributes
public:
	CMidPointCircleDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMidPointCircleView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	int m_c;
	void change();
	int CirPot(CDC *pDC,int x0, int y0, int x, int y, COLORREF color);
	void MidpointCircle(CDC *pDC,int x0, int y0, int r, COLORREF color);
	virtual ~CMidPointCircleView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	int ComputeRadius(CPoint cenp,CPoint ardp);
	int m_ist;
	CPoint m_bR;
	CPoint m_bO;
	int m_r;
	//{{AFX_MSG(CMidPointCircleView)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void Onkaishi();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MidPointCircleView.cpp
inline CMidPointCircleDoc* CMidPointCircleView::GetDocument()
   { return (CMidPointCircleDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MIDPOINTCIRCLEVIEW_H__4D7E4A7A_1390_42C6_B502_BEA1F06EFD3A__INCLUDED_)
