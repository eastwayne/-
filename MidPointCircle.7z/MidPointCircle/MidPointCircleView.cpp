// MidPointCircleView.cpp : implementation of the CMidPointCircleView class
//

#include "stdafx.h"
#include "MidPointCircle.h"
#include "math.h"

#include "MidPointCircleDoc.h"
#include "MidPointCircleView.h"
#define c 0
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMidPointCircleView

IMPLEMENT_DYNCREATE(CMidPointCircleView, CView)

BEGIN_MESSAGE_MAP(CMidPointCircleView, CView)
	//{{AFX_MSG_MAP(CMidPointCircleView)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_kaishi, Onkaishi)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMidPointCircleView construction/destruction

CMidPointCircleView::CMidPointCircleView()
{
	// TODO: add construction code here
	m_bO.x=0;  m_bO.y=0;  //Բ��
   m_bR.x=0;  m_bR.y=0;  //Բ�ϵĵ�
   m_ist=0;   //Բ����Բ�ϵĵ�����
   m_r=0;  //Բ�İ뾶
	

}

CMidPointCircleView::~CMidPointCircleView()
{
}

BOOL CMidPointCircleView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMidPointCircleView drawing

void CMidPointCircleView::OnDraw(CDC* pDC)
{
	CMidPointCircleDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
//	MidpointCircle(pDC,100, 100, 10, RGB(255,0,0));
//    MidpointCircle(pDC,500, 300, 60, RGB(255,255,0));

}

/////////////////////////////////////////////////////////////////////////////
// CMidPointCircleView printing

BOOL CMidPointCircleView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CMidPointCircleView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CMidPointCircleView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CMidPointCircleView diagnostics

#ifdef _DEBUG
void CMidPointCircleView::AssertValid() const
{
	CView::AssertValid();
}

void CMidPointCircleView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMidPointCircleDoc* CMidPointCircleView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMidPointCircleDoc)));
	return (CMidPointCircleDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMidPointCircleView message handlers

void CMidPointCircleView::MidpointCircle(CDC *pDC, int x0, int y0, int r, COLORREF color)
{
	int x,y;
  float d;
  x=0;y=r;d=1.25-r;
  CirPot(pDC,x0,y0,x,y,color);
while (x<=y)
{
 if(d<0)
 {
    d+=2*x+3; x++;
  }
  else
   {
     d+=2*(x-y)+5;
    x++;  y--;
    }
   CirPot(pDC,x0,y0,x,y,color);
   }  /*  while*/


}

int CMidPointCircleView::CirPot(CDC *pDC, int x0, int y0, int x, int y, COLORREF color)
{
   pDC->SetPixel((x0+x),(y0+y),color);
   pDC->SetPixel((x0+y),(y0+x),color);
   pDC->SetPixel((x0+y),(y0-x),color);
   pDC->SetPixel((x0+x),(y0-y),color);
   pDC->SetPixel((x0-x),(y0-y),color);
   pDC->SetPixel((x0-y),(y0-x),color);
   pDC->SetPixel((x0-y),(y0+x),color);
   pDC->SetPixel((x0-x),(y0+y),color);
   return 0;
}




int CMidPointCircleView::ComputeRadius(CPoint cenp, CPoint ardp)
{
  int dx=cenp.x-ardp.x;
  int dy=cenp.y-ardp.y;
  //sqrt()�����ĵ��ã���ͷ�ļ��м���#include "math.h"
  return (int)sqrt(dx*dx+dy*dy);


}

void CMidPointCircleView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_c==1){
	CDC *pDC=GetDC();
    pDC->SelectStockObject(NULL_BRUSH);
	if (!m_ist)  //����Բ
	{
	m_bO=m_bR=point; //��¼��һ�ε������λ�ã���Բ��
	m_ist++;
	}
	else
	{
	m_bR=point;  //��¼�ڶ��ε�������λ�ã���Բ���ϵĵ�
	m_ist--;   // Ϊ�»�ͼ��׼��
	m_r=ComputeRadius(m_bO,m_bR);
    MidpointCircle(pDC,m_bO.x,m_bO.y,m_r,RGB(255,0,0));
	}
	ReleaseDC(pDC); //�ͷ��豸����
	
		}
	CView::OnLButtonDown(nFlags, point);
}

void CMidPointCircleView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(m_c==1){
	CDC *pDC=GetDC();
   	int nDrawmode=pDC->SetROP2(R2_NOT); 
   //��������ͼģʽ��������ԭ����ͼģʽ
	pDC->SelectStockObject(NULL_BRUSH);
	if(m_ist==1)
	{  CPoint prePnt,curPnt;
	    prePnt=m_bR;  //���������ڵ�ǰһλ��
	    curPnt=point;
         m_r=ComputeRadius(m_bO,prePnt); //������Ƥ����         
		 MidpointCircle(pDC,m_bO.x,m_bO.y,m_r,RGB(255,0,0));
       //�����ģʽ�ظ���Բ������������Բ
	   m_r=ComputeRadius(m_bO,curPnt); 
       MidpointCircle(pDC,m_bO.x,m_bO.y,m_r,RGB(255,0,0)); //�õ�ǰλ����ΪԲ���ϵĵ㻭Բ
	    m_bR=point;
}
	pDC->SetROP2(nDrawmode);  //�ָ�ԭ��ͼģʽ
	ReleaseDC(pDC);  //�ͷ��豸����
				}
	CView::OnMouseMove(nFlags, point);
}

void CMidPointCircleView::Onkaishi() 
{
	// TODO: Add your command handler code here
	change();
}




void CMidPointCircleView::change()
{
	m_c=1;
}
